
package com.mycompany.basicojfx.Utils;

import com.mycompany.basicojfx.model.ObjConexion;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

/**
 *
 * @author Agustín
 */
public class UtilidadesConexion {
    
    public static Connection getConexion(ObjConexion c) throws ClassNotFoundException, SQLException{
        
        Connection conexion = null;
        
        if(c==null){
           return null;
        }
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        conexion = DriverManager.getConnection("jdbc:mysql://"+c.getHost()+"/"+c.getDb()+"?useTimezone=true&serverTimezone=UTC",c.getUser(),c.getPassword());
        
        return conexion;
    }
}
