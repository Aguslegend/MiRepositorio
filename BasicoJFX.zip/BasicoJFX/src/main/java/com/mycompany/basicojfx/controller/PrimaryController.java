package com.mycompany.basicojfx.controller;

import com.mycompany.basicojfx.App;
import com.mycompany.basicojfx.model.ObjConexion;
import com.mycompany.basicojfx.model.PersonaDAO;
import com.mycompany.basicojfx.model.Persona;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PrimaryController implements Initializable {

    @FXML
    private TableView<Persona> tabla;
    @FXML
    private TableColumn<Persona, String> nombreColumna;
    @FXML
    private TableColumn<Persona, String> apellidoColumna;
    @FXML
    private TableColumn<Persona, String> descripcionColumna;
    @FXML
    private TableColumn<Persona, String> telefonoColumna;

    private ObservableList<Persona> data;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        this.data = FXCollections.observableArrayList();

        List<Persona> misPersonas = PersonaDAO.selectAll();
        data.addAll(misPersonas);

        this.nombreColumna.setCellValueFactory(eachRowData -> {
            return new SimpleObjectProperty<>(eachRowData.getValue().getNombre());
        });
        this.apellidoColumna.setCellValueFactory(eachRowData -> {
            return new SimpleObjectProperty<>(eachRowData.getValue().getApellido());
        });
        this.descripcionColumna.setCellValueFactory(eachRowData -> {
            return new SimpleObjectProperty<>(eachRowData.getValue().getDescripcion());
        });
        this.telefonoColumna.setCellValueFactory(eachRowData -> {
            return new SimpleObjectProperty<>(eachRowData.getValue().getTelefono());
        });

        //Update
        nombreColumna.setCellFactory(TextFieldTableCell.forTableColumn());
        nombreColumna.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Persona, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Persona, String> t) {
                Persona seleccionada = (Persona) t.getTableView().getItems().get(
                        t.getTablePosition().getRow());

                seleccionada.setNombre((t.getNewValue()));

                PersonaDAO p = new PersonaDAO(seleccionada);

                p.GuardarPersona();
            }
        });
        apellidoColumna.setCellFactory(TextFieldTableCell.forTableColumn());
        apellidoColumna.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Persona, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Persona, String> t) {
                Persona seleccionada = (Persona) t.getTableView().getItems().get(
                        t.getTablePosition().getRow());

                seleccionada.setApellido((t.getNewValue()));

                PersonaDAO p = new PersonaDAO(seleccionada);

                p.GuardarPersona();
            }
        });
        descripcionColumna.setCellFactory(TextFieldTableCell.forTableColumn());
        descripcionColumna.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Persona, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Persona, String> t) {
                Persona seleccionada = (Persona) t.getTableView().getItems().get(
                        t.getTablePosition().getRow());

                seleccionada.setDescripcion((t.getNewValue()));

                PersonaDAO p = new PersonaDAO(seleccionada);

                p.GuardarPersona();
            }
        });
        telefonoColumna.setCellFactory(TextFieldTableCell.forTableColumn());
        telefonoColumna.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Persona, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Persona, String> t) {
                Persona seleccionada = (Persona) t.getTableView().getItems().get(
                        t.getTablePosition().getRow());

                seleccionada.setTelefono((t.getNewValue()));

                PersonaDAO p = new PersonaDAO(seleccionada);

                p.GuardarPersona();
            }
        });
        tabla.setEditable(true);
        //Información que tiene que mostrar la tabla.
        tabla.setItems(data);
    }

    @FXML
    public void deletePersona() {
        Persona seleccionada = tabla.getSelectionModel().getSelectedItem();
        if (seleccionada != null) {
            if (!Confirmar(seleccionada.getNombre())) {
                return;
            }
            //Se borra de la Interfaz.
            data.remove(seleccionada);
            //Se borra de la base de datos.
            PersonaDAO p = new PersonaDAO(seleccionada);
            p.EliminarPersona();
        } else {
            MostrarAviso("¡Cuidado!", "No has seleccionado a ninguna Persona", "Selecciona un contacto para eliminarlo.");
        }
    }

    public void MostrarAviso(String titulo, String cabezera, String descripcion) {
        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle(titulo);
        alerta.setHeaderText(cabezera);
        alerta.setContentText(descripcion);
        alerta.showAndWait();
    }

    public boolean Confirmar(String titulo) {
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
        alerta.setTitle("Confirmar");
        alerta.setHeaderText("Se borrará el contacto seleccionado");
        alerta.setContentText("¿Está seguro de que desea eliminar el contacto " + titulo);

        Optional<ButtonType> result = alerta.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
    
    public void AbrirObjeto(){
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("agregar.fxml"));
        Parent modal;
        try {
            modal = fxmlLoader.load();
        
        Stage modalStage = new Stage();
        modalStage.setTitle("Nuevo Contacto");
        modalStage.initModality(Modality.APPLICATION_MODAL);
        modalStage.initOwner(App.rootstage);
        
        Scene modalScene = new Scene(modal);
        modalStage.setScene(modalScene);
                     
        modalStage.showAndWait();
        
        modalStage.setScene(modalScene);
        } catch (IOException ex) {
            Logger.getLogger(PrimaryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
