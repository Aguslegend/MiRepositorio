/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.basicojfx.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Agustín
 */
public class agregarController {
    @FXML
    private TextField nombre;
    @FXML
    private TextField apellido;
    @FXML
    private TextField descripcion;
    @FXML
    private TextField telefono;
    
    private PrimaryController parent;
    
    private Object params;
    
    private Stage myStage;
    
    public void initialize(URL url, ResourceBundle rb){
        
    }
    
    public void setStage(Stage myStage){
        this.myStage=myStage;
    }
    
    public void setParent(PrimaryController p){
        this.parent=p;
    }
    
    public void setParams(Object p){
        params=p;
    }
    
    @FXML
    private void añadir(){
        if (this.myStage !=null){
            this.myStage.close();
        }
    }
    
    @FXML
    private void cancelar(){
        if (this.myStage !=null){
            this.myStage.close();
        }
    }
}
