/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.basicojfx.controller;

import com.mycompany.basicojfx.model.Persona;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Agustín
 */
public class agregarController implements Initializable {

    @FXML
    private TextField nombre;
    @FXML
    private TextField apellido;
    @FXML
    private TextField descripcion;
    @FXML
    private TextField telefono;

    //Comunicar la información a la ventana padre
    private PrimaryController parent;

    //Poder cerrarse ella sola
    private Stage myStage;

    public void initialize(URL url, ResourceBundle rb) {

    }

    public void setStage(Stage myStage) {
        this.myStage = myStage;
    }

    public void setParent(PrimaryController p) {
        this.parent = p;
    }

    

    @FXML
    private void añadir() {

        String nombre = this.nombre.getText();
        String apellido = this.apellido.getText();
        String descripcion = this.descripcion.getText();
        String telefono = this.telefono.getText();

        if (nombre.trim().length() > 0 && apellido.trim().length() > 0
                && descripcion.trim().length() > 0
                && telefono.trim().length() > 0) {
                
            Persona p = new Persona(-1,nombre,apellido,descripcion,telefono);
            if (parent!=null){
                parent.cerrarVentana(p);
            }
            if (this.myStage != null) {
                this.myStage.close();
            }

        }else{
           if (parent!=null) {
               parent.MostrarAviso("Error", "Corriga los errores", "Se debe insertar información válida");
           }
        }
    }

    @FXML
    private void cancelar() {

        if (parent != null) {
            parent.cerrarVentana(null);
        }

        if (this.myStage != null) {
            this.myStage.close();
        }
    }
}
