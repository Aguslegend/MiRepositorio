
package com.mycompany.basicojfx.model;

/**
 *
 * @author Agustín
 */
public class Persona {
    
    protected int id;
    protected String nombre;
    protected String apellido;
    protected String descripcion;
    protected String telefono;

    public Persona(int id, String nombre, String apellido, String descripcion, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.descripcion = descripcion;
        this.telefono = telefono;
    }

    public Persona() {        
        this(-1,"","","","");
    }

    public int getId() {
        return id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }  
    
}
