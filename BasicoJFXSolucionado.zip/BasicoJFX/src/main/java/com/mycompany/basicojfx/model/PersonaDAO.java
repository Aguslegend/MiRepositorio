/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.basicojfx.model;

import com.mycompany.basicojfx.Utils.UtilidadesConexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Agustín
 */
public class PersonaDAO extends Persona {

    public PersonaDAO() {
        super();
    }

    public PersonaDAO(int id, String nombre, String apellido, String descripcion, String telefono) {
        super(id, nombre, apellido, descripcion, telefono);
    }

    public PersonaDAO(String nombre, String apellido, String descripcion, String telefono) {
        super(-1, nombre, apellido, descripcion, telefono);
    }

    public PersonaDAO(Persona p) {
        id = p.id;
        nombre = p.nombre;
        apellido = p.apellido;
        descripcion = p.descripcion;
        telefono = p.telefono;
    }

    public int GuardarPersona() {
        int result = -1;
        ObjConexion c = new ObjConexion();
        c.CargarDatosXML();

        try {
            java.sql.Connection csql = UtilidadesConexion.getConexion(c);

            if (this.id > 0) {
                //Editar persona
                String consulta = "UPDATE item SET nombre = ?, apellido = ?, descripcion = ?, telefono = ? WHERE id = ?";
                PreparedStatement ps = csql.prepareStatement(consulta);
                ps.setString(1, nombre);
                ps.setString(2, apellido);
                ps.setString(3, descripcion);
                ps.setString(4, telefono);
                ps.setInt(5, id);
                result = ps.executeUpdate();

            } else {
                //Insertar persona
                String consulta = "INSERT INTO persona (id,nombre,apellido,descripcion,telefono) VALUES(NULL,?,?,?,?)";
                PreparedStatement ps = csql.prepareStatement(consulta, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, nombre);
                ps.setString(2, apellido);
                ps.setString(3, descripcion);
                ps.setString(4, telefono);
                result = ps.executeUpdate();
                try ( ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        result = generatedKeys.getInt(1);
                    }
                }
                this.id = result;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }

    public int EliminarPersona() {
        int result = -1;
        if (this.id > 0) {
            ObjConexion c = new ObjConexion();
            c.CargarDatosXML();
            try {
                Connection con = UtilidadesConexion.getConexion(c);
                String consulta = "DELETE FROM persona WHERE id=" + this.id;
                PreparedStatement ps = con.prepareStatement(consulta);
                result = ps.executeUpdate();
                if (result > 0) 
                    this.id = -1;
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }

    public static List<Persona> selectAll() {
        return selectAll("");
    }

    public static List<Persona> selectAll(String pattern) {

        List<Persona> result = new ArrayList<>();
        ObjConexion c = new ObjConexion();
        c.CargarDatosXML();

        try {

            java.sql.Connection conn = UtilidadesConexion.getConexion(c);
            String q = "SELECT * FROM persona";
            if (pattern.length() > 0) {
                q += " WHERE nombre LIKE ?";
            }
            PreparedStatement ps = conn.prepareStatement(q);

            if (pattern.length() > 0) {
                ps.setString(1, pattern + "%");
            }
            ResultSet rs = ps.executeQuery();
            if (rs != null) {

                while (rs.next()) {
                    Persona p = new Persona();
                    p.setId(rs.getInt("id"));
                    p.setNombre(rs.getString("nombre"));
                    p.setApellido(rs.getString("apellido"));
                    p.setDescripcion(rs.getString("descripcion"));
                    p.setTelefono(rs.getString("telefono"));
                    result.add(p);
                }
            }
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
            Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            System.out.println(ex);
            Logger.getLogger(PersonaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return result;
    }
}
